<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    

    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
</head>

<body class="antialiased">
    <div class="relative flex items-top justify-center min-h-screen  sm:items-center py-4 sm:pt-0">
        <?php if(Route::has('login')): ?>
        <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(url('/dashboard')); ?>" class="text-sm text-black-700 dark:text-black-500 underline">Dashboard</a>
            <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="text-sm text-black-700 dark:text-black-500 underline">Log in</a>

            <?php if(Route::has('register')): ?>
            <a href="<?php echo e(route('register')); ?>"
                class="ml-4 text-sm text-black-700 dark:text-black-500 underline">Register</a>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>


        <div class="grid grid-cols-3 gap-4">
            <div class=""></div>
            <div class="text-2xl text-center font-bold">Materials:</div>
            <div class=""></div>
            <?php if($materials->count() <= 0): ?> <div class="">
        </div>
        <div class="text-xl text-center font-bold">Tidak ada Materi</div>
        <div class=""></div>
        <?php endif; ?>
        <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('guest-material', $material->id)); ?>">
            <div class="border rounded shadow ">
                <h1 class="text-lg font-bold p-5">
                    <?php echo e($material->title); ?>

                </h1>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
</body>

</html>
<?php /**PATH C:\laragon\www\boilerplate\resources\views/welcome.blade.php ENDPATH**/ ?>