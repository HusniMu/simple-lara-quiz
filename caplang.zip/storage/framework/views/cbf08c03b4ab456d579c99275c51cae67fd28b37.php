 <?php $__env->slot('header', null, []); ?> 
    <h2 class="text-xl font-semibold leading-tight text-gray-800">
        <?php echo e(__('Quiz '.$quiz->question->title)); ?>

    </h2>
 <?php $__env->endSlot(); ?>
<div class="py-12">
    <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
        <div class="overflow-hidden bg-white shadow-xl sm:rounded-lg">
            
            <?php if($status === 'instruction'): ?>
            <div class="m-5">
                <h1>Instruction</h1>
                <h1>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis beatae corrupti atque nihil
                    repudiandae perferendis molestiae odit soluta ullam architecto modi, dolores odio explicabo sit at
                    possimus repellendus nulla reprehenderit.
                </h1>
                <button class="px-5 py-2 text-white bg-green-500 border rounded hover:bg-green-400"
                    wire:click="changeStatus('quiz')">Start</button>
            </div>
            <?php elseif($status === 'quiz'): ?>
            <div class="m-5">
                <h1>Question <?php echo e($no); ?>/<?php echo e($totalQuestion); ?></h1>
                <hr>
                <h1 class="text-3xl">
                    <?php echo e($question->question); ?>

                </h1>
                <?php $__currentLoopData = json_decode($question->answer); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center mt-2">
                    <input type="radio" class="p-3 mr-3 <?php echo e($mySelected!== null ? 'text-gray-500' : 'text-black'); ?>"
                        name="detail-correct" value="<?php echo e($index); ?>" wire:click="choiceOption(<?php echo e($index); ?>)" <?php echo e($mySelected===$index ? 'checked' : ''); ?> <?php echo e($mySelected!==null ? 'disabled' : ''); ?> />
                    <label for=""
                        class="text-xl form-check-label <?php echo e($mySelected !== null ? 'text-gray-500' : 'text-black'); ?>">
                        <?php echo e($answer); ?>

                    </label>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <hr>
                <div class="flex justify-between mt-2">
                    
                    <?php if($mySelected !== null): ?>
                    <button class="px-4 py-2 text-white bg-indigo-600 border rounded shadow hover:bg-indigo-500"
                        wire:click="nextQuestion">
                        next
                    </button>
                    <?php endif; ?>
                </div>
                <?php if($mySelected !== null): ?>
                <div class="mt-2">
                    <?php echo e($result); ?>

                    <br>
                    <?php echo e($argument); ?>

                    <?php if($material !== null): ?>
                    <br>
                    <?php echo e($material->title); ?>

                    <br>
                    <?php echo e($material->body); ?>

                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            
            <?php elseif($status === 'summary'): ?>
            <div class="m-5">
                <h1>finish</h1>
                <hr>
                <h1>correct answer <?php echo e($correct); ?></h1>
                <h1>score <?php echo e(round(($correct*100)/$totalQuestion)); ?></h1>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\boilerplate\resources\views/livewire/quizzes.blade.php ENDPATH**/ ?>