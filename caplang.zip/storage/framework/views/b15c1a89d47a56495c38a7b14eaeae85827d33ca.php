<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">

    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
</head>

<body class="antialiased">
    <div class="relative flex items-top justify-center min-h-screen  sm:items-center py-4 sm:pt-0">
        <?php if(Route::has('login')): ?>
        <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(url('/dashboard')); ?>" class="text-sm text-black-700 dark:text-black-500 underline">Dashboard</a>
            <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="text-sm text-black-700 dark:text-black-500 underline">Log in</a>

            <?php if(Route::has('register')): ?>
            <a href="<?php echo e(route('register')); ?>"
                class="ml-4 text-sm text-black-700 dark:text-black-500 underline">Register</a>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <hr>
        <div class="mt-5 p-5 w-6/12 border rounded shadow">
            <h1 class="text-2xl font-bold">
                <?php echo e($material->title); ?>

            </h1>
            <h1 class="text-xl font-semibold">
                <?php echo e($material->body); ?>

            </h1>
            <a href="<?php echo e(route('welcome')); ?>">
                <p class="text-xs">back</p>
            </a>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\laragon\www\boilerplate\resources\views/guest-material.blade.php ENDPATH**/ ?>