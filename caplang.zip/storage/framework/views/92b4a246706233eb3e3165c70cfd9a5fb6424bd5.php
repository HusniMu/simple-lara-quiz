<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Report Details')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
                <div class="overflow-hidden bg-white shadow-xl sm:rounded-lg">
                    <div class="border rounded shadow p-5">
                        <h1 class="text-2xl">Judul uji: <?php echo e($quiz->user->name); ?></h1>
                        <h1>Peserta uji: <?php echo e($quiz->user->name); ?></h1>
                        <h1>Waktu uji: <?php echo e($quiz->created_at); ?></h1>
                        <h1>Status uji: <?php echo e($quiz->status); ?></h1>
                    </div>
                    <div class="border rounded shadow mt-5 p-5">
                        <?php $__currentLoopData = $quizDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border rounded shadow mt-5 p-5">
                            <table>
                                <tr>
                                    <td>Pertanyaan</td>
                                    <td>: <?php echo e($qd->question); ?></td>
                                </tr>
                                <tr>
                                    <td>
                                        Pilihan
                                    </td>
                                    <td>:</td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td>
                                        <input type="hidden" value="<?php echo e($i = 1); ?>">
                                        <?php $__currentLoopData = json_decode($qd->answer); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($i); ?>)&nbsp;&nbsp;<?php echo e($answer); ?>

                                        <br>
                                        <input type="hidden" value="<?php echo e($i++); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Jawaban Peserta Uji</td>
                                    <td>:
                                        <?php echo e(($qd->user_answer!== null)?$qd->user_answer+1:'-'); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>Jawaban Benar</td>
                                    <td>: <?php echo e($qd->correct_answer+1); ?></td>
                                </tr>
                                <tr>
                                    <td>Hasil</td>
                                    <td>: <?php echo e(($qd->correct_answer === $qd->user_answer)? 'Benar': 'Salah'); ?></td>
                                </tr>
                            </table>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\boilerplate\resources\views/report-details.blade.php ENDPATH**/ ?>