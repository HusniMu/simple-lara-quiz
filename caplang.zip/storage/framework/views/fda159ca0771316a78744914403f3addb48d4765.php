 <?php $__env->slot('header', null, []); ?> 
    <h2 class="text-xl font-semibold leading-tight text-gray-800">
        <?php echo e(__('History')); ?>

    </h2>
 <?php $__env->endSlot(); ?>
<div class="py-12">
    <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
        <div class="overflow-hidden bg-white shadow-xl sm:rounded-lg">
            <div class="m-5">
                <div class="flex justify-between w-full mb-1">
                    <input type="text" wire:model="historySearch" class="w-full border rounded shadow">
                </div>
                <div class="mb-1">
                    <table class="w-full rounded table-auto">
                        <thead>
                            <tr>
                                <th>
                                    Title
                                </th>
                                <th>
                                    Created At
                                </th>
                                <th>
                                    Status
                                </th>
                                <th>
                                    Score
                                </th>
                                <th>
                                    Actions
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($history->title); ?></td>
                                <td><?php echo e($history->created_at->diffForHumans()); ?></td>
                                <td><?php echo e($history->status); ?></td>
                                <td><?php echo e($history->score ?? 0); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('quizzes',['quiz'=>$history->id])); ?>">
                                        <i
                                            class="p-1 text-white bg-blue-700 border rounded fa fa-pencil hover:bg-blue-500"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\boilerplate\resources\views/livewire/history.blade.php ENDPATH**/ ?>