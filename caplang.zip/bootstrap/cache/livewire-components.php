<?php return array (
  'history' => 'App\\Http\\Livewire\\History',
  'materials' => 'App\\Http\\Livewire\\Materials',
  'materials-form' => 'App\\Http\\Livewire\\MaterialsForm',
  'questions' => 'App\\Http\\Livewire\\Questions',
  'questions-form' => 'App\\Http\\Livewire\\QuestionsForm',
  'quizzes' => 'App\\Http\\Livewire\\Quizzes',
  'reports' => 'App\\Http\\Livewire\\Reports',
  'roles' => 'App\\Http\\Livewire\\Roles',
  'roles-modal' => 'App\\Http\\Livewire\\RolesModal',
  'user-materials' => 'App\\Http\\Livewire\\UserMaterials',
  'users' => 'App\\Http\\Livewire\\Users',
  'users-modal' => 'App\\Http\\Livewire\\UsersModal',
);