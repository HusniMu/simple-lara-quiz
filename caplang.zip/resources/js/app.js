require('./bootstrap')

// var Turbolinks = require('turbolinks')
// Turbolinks.start()

import Alpine from 'alpinejs'

window.Alpine = Alpine

Alpine.start()
